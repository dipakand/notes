// import { NgForm } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, NgForm} from '@angular/forms';
import { ResultService } from '../result.service';
import { Result } from '../result';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {
  title = 'Result';
  results: Result[];
  resForm: FormGroup;
  // tslint:disable-next-line: variable-name
  constructor(private formbuilder: FormBuilder , private _ResultService: ResultService, private titleService: Title) {
    this.resForm = formbuilder.group({
      date1: new FormControl(),

   });
  }

  ngOnInit() {

    this.titleService.setTitle(this.title);

    this._ResultService.getResults1()
    .subscribe((data: Result[]) => {
      this.results = data;
      console.log(this.results);
    });
  }

  resultdate(resForm1: NgForm) {
    console.log(resForm1.value);
    this._ResultService.getResults2(resForm1.value)
    .subscribe((data: Result[]) => {
      this.results = data;
      // console.log(data);
    });
  }
}
