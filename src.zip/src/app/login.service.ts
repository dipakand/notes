import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Login } from './result';
import * as $ from 'jquery';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }


  loginUser( loginusr: Login ) {
    // alert(loginusr);
    return this.http.post('http://11.0.0.200:8080/dipak/gambling_api/login/login.php', loginusr);
    }

    // getbalance() {
    //     let sesss_id:any = sessionStorage.getItem('sess_user_id');
    //     return this.http.get<Login>('http://11.0.0.200:8080/dipak/gambling_api/fetch_balance.php/?sesss_id=${sesss_id}');
    // }
}
