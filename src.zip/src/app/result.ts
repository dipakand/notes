export class Result {
}

export class Login {
}
