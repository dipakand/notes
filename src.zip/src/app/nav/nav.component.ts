import { Component, OnInit } from '@angular/core';
import { ResultService } from '../result.service';
import { Result } from '../result';
@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  balance: Result[];
  username = sessionStorage.getItem('sess_username');
  constructor(private _ResultService: ResultService) { }

  ngOnInit() {
      this._ResultService.getbalance()
      .subscribe((data: Result[]) => {
        this.balance = data;
        // this.username = sessionStorage.getItem('sess_username');
        console.log(sessionStorage.getItem('sess_username'));
    });
  }
}
