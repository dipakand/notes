import { Component, OnInit } from '@angular/core';
import * as $ from '../../../assets/js/jquery.min.js';
import { LoginService } from '../../Login.service';
import { Router } from '@angular/router';
import { Login } from '../../result';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loguser: Login[];
  constructor(private _loginService : LoginService ,
    private router : Router
    ) { }

  ngOnInit() {
  }

  Register(regForm: any){
    // console.log(regForm.value);
    this._loginService.loginUser(regForm.value)
    .subscribe((data: Login[]) => {
      this.loguser = data;
      console.log(this.loguser[0]);
      // this.router.navigate(['view']);
      sessionStorage.setItem('sess_user_id', data[0]['sess_user_id']);
      sessionStorage.setItem('sess_username', data[0]['sess_username']);
      sessionStorage.setItem('sess_userrole', data[0]['sess_userrole']);
      // console.log(sessionStorage.getItem('sess_user_id'));
      this.router.navigate(['']);

    },
    )

  }

}
