import { Component, OnInit } from '@angular/core';
import { ResultService } from '../result.service';
import { Result } from '../result';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  results: Result[];
  constructor(private _ResultService: ResultService) { }

  ngOnInit() {
    this._ResultService.getResults()
    .subscribe((data: Result[]) => {
      this.results = data;
      // console.log(this.results);
  });

  }

}
