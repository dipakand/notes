import { Component, OnInit } from '@angular/core';
import { ResultService } from '../result.service';
import { Result } from '../result';
import { Router } from '@angular/router';
import * as $ from 'jquery';


@Component({
    selector: 'app-coins',
    templateUrl: './coins.component.html',
    styleUrls: ['./coins.component.css']
})
export class CoinsComponent implements OnInit {

    constructor(private _ResultService: ResultService, private router : Router) {}

    ngOnInit() {
        // let ResultService1 = this._ResultService;
    //    let  dateTime45='22:30';
    //     this._ResultService.batchwiseresult(dateTime45)
    //     .subscribe(data => {
    //       // console.log(this.smartphone);
    //     });
      

        let qtty: any;
        let quantity: number;
        // $(document).ready(function(){

        $('.quantity121-10').click(function(e){
            e.preventDefault();
            qtty = $('#quantity').val();
            quantity = parseInt(qtty);
            $('#quantity').val(quantity + 10);
            all_total21(10);
        });

        $('.quantity121-20').click(function(e){
            e.preventDefault();
            qtty = $('#quantity').val();
            quantity = parseInt(qtty);
            $('#quantity').val(quantity + 20);
            all_total21(20);
        });

        $('.quantity121-50').click(function(e){
            e.preventDefault();
            qtty = $('#quantity').val();
            quantity = parseInt(qtty);
            $('#quantity').val(quantity + 50);
            all_total21(50);
        });

        $('.quantity121-100').click(function(e){
            e.preventDefault();
            qtty = $('#quantity').val();
            quantity = parseInt(qtty);
            $('#quantity').val(quantity + 100);
            all_total21(100);

        });

        $('.quantity121-500').click(function(e){
            e.preventDefault();
            qtty = $('#quantity').val();
            quantity = parseInt(qtty);
            $('#quantity').val(quantity + 500);
            all_total21(500);
        });

        $('.quantity121-1000').click(function(e){
            e.preventDefault();
            qtty = $('#quantity').val();
            quantity = parseInt(qtty);
            $('#quantity').val(quantity + 1000);
            all_total21(1000);
        });

        $(document).ready(function() {
            $('html, body').animate({ scrollTop: $(document).height() }, 'slow');
        });
        // });

        $('#clear').click(function(e) {
            e.preventDefault();
            $('.token_val').val(0);
            document.getElementById('display_val').innerHTML = '';
            document.getElementById('display_val21').innerHTML = '';
        });

        let tot_11: number;
        let tot_12: any;
        function all_total21(nn) {

            document.getElementById('display_val21').innerHTML = '';
            tot_11 = parseFloat(nn);
            tot_12 = tot_11;
            document.getElementById('display_val21').innerHTML = tot_12;
        }




        var xmlHttp;
        function srvTime() {
            try {
                //FF, Opera, Safari, Chrome
                xmlHttp = new XMLHttpRequest();
            }
            catch (err1) {
                //IE
                try {
                    xmlHttp = new ActiveXObject('Msxml2.XMLHTTP');
                }
                catch (err2) {
                    try {
                        xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
                    }
                    catch (eerr3) {

                        alert("AJAX not supported");
                    }
                }
            }
            xmlHttp.open('HEAD',window.location.href.toString(),false);
            xmlHttp.setRequestHeader("Content-Type", "text/html");
            xmlHttp.send('');
            return xmlHttp.getResponseHeader("Date");
        }


        function time(a) {

            $.ajax({
                url: 'http://11.0.0.200:8080/dipak/gambling_api/time.php',
                data: { 'batch': a, 'COMMANDTYPE': 'CHANGESTATUS'},
                    success: function (response) {
                    location.href = location.href
                },
            });
        }

        function batch_result(var_data) {
            // this._ResultService.batchwiseresult(var_data)
            //   .subscribe(data => {
            //     console.log(this.data);
            //   });

              $.ajax({
      
                url: 'http://11.0.0.200:8080/dipak/gambling_api/batchwise_count_per.php',
                data: {'batch_time': var_data},
                success:function(response) {
                },
            });
          }


        function display_result(result_time){
                $.ajax({
                    url: 'http://11.0.0.200:8080/dipak/gambling_api/time.php',
                    data: {'batch_time':result_time,'user':'5','COMMANDTYPE':'WINNER'},
                    success: function (response) {
                        var res = response.split('|');
                        // <?php if(isset($_SESSION['display']) && $_SESSION['display']=='counter'){ ?>
                        // document.getElementById("winner").innerHTML = res[0];
                        // <?php } ?>
                        document.getElementById('winner').innerHTML = res[0];
                        document.getElementById('win_time').innerHTML = res[1];
                        document.getElementById('claim_amt').innerHTML = res[2];


                    },
                });
            }
        function returnDoubleDigits(str) {
            return str.length === 1 ? '0' + str : str;
        }
        let currentTime: any;
        function getDateTime() {
            let fixminte = 5;
            let st = srvTime();
            let date = new Date(st);
            let now     = date;
            // var hour    = now.getHours();
            let hour: any = now.getHours();
            let minute: any  = now.getMinutes();
            let second: any  = now.getSeconds();

            if (hour.toString().length == 1) {
                hour = '0'+ hour;
            }
            if (minute.toString().length == 1) {
                minute = '0'+ minute;
            }
            if (second.toString().length == 1) {
                second = '0'+ second;
            }

            let calmin: number = returnDoubleDigits(((Math.floor(minute / fixminte)) * fixminte) + 5);

            const plusmin = calmin;
            let value_start = returnDoubleDigits(((plusmin - minute) - 1).toString());
            let value_end = returnDoubleDigits((60 - second).toString());

            let dateTime =  hour + ':' + returnDoubleDigits((minute).toString());

            if (calmin == 60) {
                calmin = 0;
                if (hour == 23){
                    hour = 1;
                } else {
                    hour = returnDoubleDigits(hour + 1);
                }

                var dateTime1 =  hour + ':' + returnDoubleDigits((calmin).toString());
            } else {
                var dateTime1 =  hour + ':' + returnDoubleDigits((calmin).toString());
            }


            document.getElementById('clock1').innerHTML = value_start + ':' + value_end ;
            if (value_end <= 20 && value_start == 0){
                $('#submit_token' ).attr('disabled', 'true');
                $('#odd_submit').attr('disabled', 'true');
                $('#even_submit').attr('disabled', 'true');
                $('#submit_token').css('background-color', '#ed5565');
                $('#odd_submit').css('background-color', '#ed5565');
                $('#even_submit').css('background-color', '#ed5565');

            }




            if (minute % 5 == 0) {
                if (second == 0 ) {
                                       time(dateTime1);
                    // time(1);
                    batch_result(dateTime);

                }
                display_result(dateTime1);
                if (second <= 3 ) {
                    //                <?php unset($_SESSION['display']); ?>
                }
            }
            else {
                display_result(dateTime1);

            }
        }
        setInterval(function() {
            currentTime = getDateTime();
        }, 1000);


        $('#submit_token').click(function(e){
      
            let custom_arr1 = [];
            let abcd: any = 0;
            let tott: any = 0;
            let batch_time: any = $('#batch_time').val();

            for (let i = 0; i < 10; i++)
            {
                abcd = $('#quantity_' + i).val();
                custom_arr1.push(abcd);
                tott = parseFloat(tott) + parseFloat(abcd);
            }
            if (tott > 0 ) {


                $.ajax({
                    type: 'post',
                    url: 'http://11.0.0.200:8080/dipak/gambling_api/ajax_submit.php',
                    data: {'ajax_qtnty': custom_arr1,'batch_time': batch_time, 'COMMANDTYPE': 'submitt'},
                    success:function(response) {
                        if (response === 'a2') {
                            alert('Problem While Submitting Tokens');
                        }
                        else if (response === 'a3') {
                            alert('Please Insert Token Value');
                        }
                        else if (response === 'a4') {
                            alert('Insufficient Balance');
                        }
                        else if (response === 'a5') {
                            alert('Inappropriate Batch Time');
                        }
                        else{
                            $('.token_val').val(0);
                            document.getElementById('display_val').innerHTML = '';
                            document.getElementById('display_val21').innerHTML = '10';
                            let src1 = 'http://11.0.0.200:8080/dipak/token/user/print_view_sale.php?id=' + response;
                            // var src1="<?php echo $company['url']; ?>?id="+response;
                            $('#iframe_disp').attr('src', src1);
                        }

                    }
                });
            }




        });

    }



    odd_submit_fuc(vall) {   
    
        var displval_odd:any =  document.getElementById('display_val21').innerHTML;
        let qty1: any;
        if(displval_odd==''){
            displval_odd=0;
        }
        if(Number(displval_odd) > 0){
            if(vall==1) {

                var  command = 'odd_sub';
                var tot = 0;
                var tot1 = 0;
                var totall = 0;
                for (let i=0; i < 10; i++) {

                    if (i%2 == 1)
                    {

                        qty1 = $('#quantity_'+i).val();
                        totall = parseFloat(displval_odd) + parseFloat(qty1);
                        $('#quantity_'+i).val(totall);
                        tot = tot + totall;

                    } 
                    else{

                        qty1= $('#quantity_'+i).val();
                        tot1 = tot1 + parseFloat(qty1);

                    }

                    var display:any = tot1 +tot;
                    document.getElementById('display_val').innerHTML=display;

                }

            }
            else{
                var tot2 = 0;
                var tot21 = 0;
                var totall=0;
                for (let i=0; i < 10; i++)
                {

                    if(i%2==0)
                    {

                        qty1= $('#quantity_'+i).val();
                        totall=parseFloat(displval_odd)+parseFloat(qty1);
                        $('#quantity_'+i).val(totall);

                        tot2 = tot2 + totall;



                    } 
                    else{

                        qty1= $('#quantity_'+i).val();
                        tot21 = tot21 + parseFloat(qty1);

                    }


                    var display: any = tot2 +tot21;

                    document.getElementById('display_val').innerHTML=display;

                }

            }
        } 
        else{
            let qty2: any;
            if(vall==1) {
                var  command='odd_sub';
                var tot = 0;
                var tot1 = 0;
                var totall=0;

                for (let i=0; i < 10; i++)
                {

                    if(i%2==1)
                    {
                        let rupp: any = 10;
                        qty2= $('#quantity_'+i).val();
                        totall=parseFloat(rupp)+parseFloat(qty2);
                        $('#quantity_'+i).val(totall);
                        tot = tot + totall;

                    } else{

                        qty2= $('#quantity_'+i).val();
                        tot1 = tot1 + parseFloat(qty2);

                    }

                    var display: any = tot1 +tot;
                    document.getElementById('display_val').innerHTML=display;

                }

            }
            else{
                var tot2 = 0;
                var tot21 = 0;
                var totall=0;
                for (let i=0; i < 10; i++)
                {

                    if(i%2==0)
                    {

                        let rupp: any = 10;
                        qty2= $('#quantity_'+i).val();
                        totall=parseFloat(rupp)+parseFloat(qty2);
                        $('#quantity_'+i).val(totall);

                        tot2 = tot2 + totall;



                    } else{

                        qty2= $('#quantity_'+i).val();
                        tot21 = tot21 + parseFloat(qty2);

                    }

                    var display: any = tot2 +tot21;

                    document.getElementById('display_val').innerHTML=display;

                }

            }
        }

    }



}
