import { Component, OnInit } from '@angular/core';
import * as $ from '../../../assets/js/jquery.min.js';
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {

    $('#menu-toggle').click(function(e) {
      e.preventDefault();
      $('#wrapper').toggleClass('toggled');
    });
    $('#menu-toggle-2').click(function(e) {
      e.preventDefault();
      $('#wrapper').toggleClass('toggled-2');
      $('#menu ul').hide();
    });

 
    $(window).load(function () {
      $('#wrapper').toggleClass('toggled-2');
             $('#menu ul').hide();
    });

    $(document).ready(function() {
      // $('[data-toggle="tooltip"]').tooltip();   

    });
  }

}
