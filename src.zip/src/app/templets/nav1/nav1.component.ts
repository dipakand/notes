import { Component, OnInit } from '@angular/core';
import { ResultService } from '../../result.service';
import { Result } from '../../result';

@Component({
  selector: 'app-nav1',
  templateUrl: './nav1.component.html',
  styleUrls: ['./nav1.component.css']
})
export class Nav1Component implements OnInit {
  balance: Result[];
  username = sessionStorage.getItem('sess_username');
  constructor(private _ResultService: ResultService) { }

  ngOnInit() {
    this._ResultService.getbalance()
    .subscribe((data: Result[]) => {
      this.balance = data;
      // console.log(this.balance);
  });
  }

}
