import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { NavComponent } from './nav/nav.component';
import { CountdownComponent } from './countdown/countdown.component';
import { TokensComponent } from './tokens/tokens.component';
import { CoinsComponent } from './coins/coins.component';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ResultService } from './result.service';
import { FormsModule } from '@angular/forms';
import { SalesComponent } from './sales/sales.component';
import { ResultComponent } from './result/result.component';
import { MenuComponent } from './templets/menu/menu.component';
import { Nav1Component } from './templets/nav1/nav1.component';
import { LoginComponent } from './login/login/login.component';
import { LogoutComponent } from './login/logout/logout.component';
// export const routes: Routes = [
//   { path: '', component: HeaderComponent, pathMatch: 'full'},
//   { path: 'view', component: HeaderComponent },
// ];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    NavComponent,
    CountdownComponent,
    TokensComponent,
    CoinsComponent,
    SalesComponent,
    ResultComponent,
    MenuComponent,
    Nav1Component,
    LoginComponent,
    LogoutComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
    // RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
