import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl,FormBuilder,NgForm} from '@angular/forms';
import * as $ from 'jquery';
import { Router } from '@angular/router';
import { Result } from '../result';
import { ResultService } from '../result.service';

@Component({
    selector: 'app-tokens',
    templateUrl: './tokens.component.html',
    styleUrls: ['./tokens.component.css']
})
export class TokensComponent implements OnInit {
    addForm: FormGroup;
    quantity: any='';
    batches: Result[];
    constructor(  
        private formbuilder: FormBuilder ,
        private _resultService : ResultService ,
        private router : Router) {
            this.addForm = formbuilder.group({


                quantity: new FormControl(),
             });
         }

    ngOnInit() {
  
        if (!sessionStorage.getItem('sess_user_id')){
            sessionStorage.clear();
            this.router.navigate(['login']);
        }
        else {
        }

        $(document).ready(function(){
            var quantitiy=0;

            for (let i = 0; i < 10; i++) {
                let qty: any;
                let quantity: number;
                $('.quantity-20_'+i).click(function(e){

                    e.preventDefault();
                    qty = $('#quantity_'+i).val();
                    quantity = parseInt(qty);
                    $('#quantity_'+i).val(quantity + 20);
                    all_total(20);
                });

                $('.quantity-50_'+i).click(function(e){
                    e.preventDefault();
                    qty = $('#quantity_'+i).val();
                    quantity = parseInt(qty);
                    $('#quantity_'+i).val(quantity + 50);
                    all_total(50);
                });

                $('.quantity-100_'+i).click(function(e){
                    e.preventDefault();
                    qty = $('#quantity_'+i).val();
                    quantity = parseInt(qty);
                    $('#quantity_'+i).val(quantity + 100);
                    all_total(100);

                });

                $('.quantity-500_'+i).click(function(e){
                    e.preventDefault();
                    qty = $('#quantity_'+i).val();
                    quantity = parseInt(qty);
                    $('#quantity_'+i).val(quantity + 500);
                    all_total(500);
                });

                $('#clear_'+i).click(function(e){
                    e.preventDefault();
                    $('#quantity_'+i).val(0);
                });


                let display_val21: any;
                $('.token_fetch_'+i).click(function(e){
                    e.preventDefault();
                    qty = $('#quantity_'+i).val();
                    quantity = parseInt(qty);
                    display_val21=  document.getElementById('display_val21').innerHTML;
                    if(display_val21 ==''){
                        display_val21 = 0;
                    }
                    var tot_fet_qty=quantity + parseInt(display_val21)
                    $('#quantity_'+i).val(tot_fet_qty);
                    all_total(tot_fet_qty);


                });
            }

        });


        function all_total1(){
            let totall: any = 0;
            let qty: any;
            for (let i = 0; i < 10; i++) {      

                qty= $('#quantity_'+i).val();
                if(qty !=''){

                    totall=parseFloat(totall)+parseFloat(qty);
                }

            }
            document.getElementById('display_val').innerHTML=totall;
        }
        function all_total(nn){
            let totall: any=0;
            let qty: any;
            for (let i = 0; i < 10; i++) {       
                qty= $('#quantity_'+i).val();
                if(qty !=''){

                    totall=parseFloat(totall)+parseFloat(qty);
                }
            }
            document.getElementById('display_val').innerHTML=totall;

        }

  
        this._resultService.getbatches()
        .subscribe((data: Result[]) => {
          this.batches = data;
        //   console.log(this.batches);
      });
    }

    fruits:any[]=['LYCHEE','BANANA','APPLE','LEMON','MANGO','GUAVA','ORANGE','PINEAPPLE','TOMATO','CHILLY']

bgi:any[]=['lychee','banana','apple','lemon','mango','guava','orange','pineapple','tomato','chilly']
bgc:any[]=['#32a42e','#9c260c','#ba20e6','#bcda66','#b9702d','#db8b13','#34abd5','#ff69ff','#2f63c1','#284eff']


PostData(addForm: NgForm){
  
    console.log(this.addForm.value);
   
  }

}
