import { TokensComponent } from './tokens/tokens.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SalesComponent } from './sales/sales.component';
import { ResultComponent } from './result/result.component';
import { LoginComponent } from './login/login/login.component';
import { LogoutComponent } from './login/logout/logout.component';
const routes: Routes = [
{
  path: '', component: TokensComponent
},
{
  path: 'sales', component: SalesComponent
},
{
  path: 'result', component: ResultComponent
},
{
  path: 'login', component: LoginComponent
},
{
  path: 'logout', component: LogoutComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
