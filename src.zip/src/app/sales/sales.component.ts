import { Component, OnInit } from '@angular/core';
import { ResultService } from '../result.service';
import { Result } from '../result';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder,NgForm} from '@angular/forms';
@Component({
  selector: 'app-sales',
  templateUrl: './sales.component.html',
  styleUrls: ['./sales.component.css']
})
export class SalesComponent implements OnInit {
  user_role: string = sessionStorage.getItem('sess_userrole');
  username = sessionStorage.getItem('sess_username');
  sess_user_id = sessionStorage.getItem('sess_user_id');
  partytype: Result[];
  SerachForm: FormGroup;
  comm: any;
  resultdetail: Result[];
  resultdelete: Result;

  constructor(private formbuilder: FormBuilder ,private _ResultService: ResultService , private router : Router) {

    this.SerachForm = formbuilder.group({
      date_from: new FormControl(),
      date_to: new FormControl(),
      soption: new FormControl(),
      sel_user: new FormControl()
   });
   }

  ngOnInit() {
    let xmlHttp;
    function srvTime(){
      try {
        xmlHttp = new XMLHttpRequest();
      }
      catch (err1) {
        //IE
        try {
          xmlHttp = new ActiveXObject('Msxml2.XMLHTTP');
        }
        catch (err2) {
          try {
            xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
          }
          catch (eerr3) {
            //AJAX not supported, use CPU time.
            alert('AJAX not supported');
          }
        }
      }
      xmlHttp.open('HEAD',window.location.href.toString(),false);
      xmlHttp.setRequestHeader('Content-Type', 'text/html');
      xmlHttp.send('');
      return xmlHttp.getResponseHeader('Date');
    }
    function returnDoubleDigits(str) {
      return str.length === 1 ? '0' + str : str;
    }
    let currentTime: any;
    function getDateTime() {
      let fixminte = 5;
      let st = srvTime();
      let date = new Date(st);
      let now     = date;
      let hour: any    = now.getHours();
      let minute: any  = now.getMinutes();
      let second: any  = now.getSeconds();

      if (hour.toString().length == 1) {
        hour = '0' + hour;
      }
      if (minute.toString().length == 1) {
        minute = '0' + minute;
      }
      if (second.toString().length == 1) {
        second = '0' + second;
      }

      let calmin = returnDoubleDigits(((Math.floor(minute / fixminte)) * fixminte) + 5);
      let plusmin = calmin;
      let value_start = returnDoubleDigits(((plusmin - minute) - 1).toString());
      let value_end = returnDoubleDigits((60 - second).toString());
      if (calmin == 60) {
        calmin = 0;
        if (hour == 23) {
          hour = 1;
        } else {
          hour = returnDoubleDigits(hour + 1);
        }

        var dateTime1 =  hour + ':' + returnDoubleDigits((calmin).toString());
      } else {
        var dateTime1 =  hour + ':' + returnDoubleDigits((calmin).toString());
      }
  
      let current_time = hour + ':' + minute;
      if (current_time < dateTime1){
        if (value_end <= 20 && value_start== 0) {
          $( '.cancel_token' ).addClass( 'disabled');
        }
      }
      if (minute % 5 == 0) {
        if (second == 0 ) {
          location.href = location.href
        }
      }
    }
    setInterval(function() {
      currentTime = getDateTime();
    }, 1000);


    this._ResultService.serachSales1()
    .subscribe((data: Result[])  => {
      // console.log(data);
      this.partytype = data;
      this.comm = data[0]['partytype'];
      // console.log(this.partytype);

    },
  );
// console.log('ngOnInit');
    let serchdate123 =sessionStorage.getItem('ngserach');
    console.log(serchdate123);
    this._ResultService.serachSales(serchdate123).subscribe((data: Result[])  => {  this.partytype = data;
      this.comm = data[0]['partytype']; },);
  }


  Search(serchdate: NgForm) {
    sessionStorage.setItem('ngserach',serchdate.value);
  // let party_type = '';
  // let Comm = '';
  // let TS = '';
  // let TC = '';
  // let TR = '';
  // let NTP = '';
  // let LD = '';
  // let NTC = '';
    console.log(serchdate.value);
    this._ResultService.serachSales(serchdate.value)
      .subscribe((data: Result[])  => {
        // console.log(data);
        this.partytype = data;
        this.comm = data[0]['partytype'];
        // console.log(this.partytype);
 
      },
    ),
    this._ResultService.serachSales2(serchdate.value)
    .subscribe((data1: Result[])  => {
        console.log(data1);
        this.resultdetail = data1;

    },
  );
  }

  deletetoken(deletevalue) {
    // alert(deletevalue);
    this._ResultService.deletetoken(deletevalue)
    .subscribe(data2   => {
        // console.log(data2);
        // this.resultdelete = data2;
        // if (this.resultdelete === 1) {

        // }
        this.ngOnInit();
        // this.router.navigateByUrl("/reload");
    },
  );
  }

}
