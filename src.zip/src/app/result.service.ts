import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Result } from './result';
import * as $ from 'jquery';

@Injectable({
  providedIn: 'root'
})
export class ResultService {

  // tslint:disable-next-line: variable-name
  sesss_id = sessionStorage.getItem('sess_user_id');
  userrole = sessionStorage.getItem('sess_userrole');
  username = sessionStorage.getItem('sess_username');

  // tslint:disable-next-line: variable-name
  private http_url = 'http://11.0.0.200:8080/dipak/gambling_api';
  constructor(private http: HttpClient) { }
  getResults() {
     return this.http.get<Result[]>(`${this.http_url}/fetch_batch_reslt.php`);
   }
   getResults1() {

    // return this.http.get<Result[]>('http://11.0.0.200:8080/dipak/gambling_api/result.php');
    return this.http.get<Result[]>(`${this.http_url}/fetch_batch_reslt.php`);

  }

  getResults2(resform: Result) {
    // alert(resform);
    return this.http.post(`${this.http_url}/result.php`, resform);
  }
   getbalance() {
    return this.http.get<Result>(`${this.http_url}/fetch_balance.php/?sesss_id=` + this.sesss_id);
   }
   getbatches() {

    return this.http.get<Result[]>(`${this.http_url}/fetch_batches.php`);

   }
   // tslint:disable-next-line: variable-name
   batchwiseresult( batch_res: Result ) {
    return this.http.post(`${this.http_url}/batchwise_result.php`, { ' batch_res' : batch_res});
  }


   createStudent(token: Result) {
    return this.http.post('http://localhost/angular/php/insert.php', token);
  }
  serachSales(token: Result) {
      // tslint:disable-next-line: max-line-length
      return this.http.post(`${this.http_url}/month_to_date.php/?sess_user_id=` + this.sesss_id + `&&userrole=` + this.userrole + `&&username=` + this.username, token);
  }

  serachSales1() {
  // tslint:disable-next-line: max-line-length
  return this.http.get(`${this.http_url}/month_to_date.php/?sess_user_id=` + this.sesss_id + `&&userrole=` + this.userrole + `&&username=` + this.username);
  }

  serachSales2(token1: Result) {

    // tslint:disable-next-line: max-line-length
    return this.http.post(`${this.http_url}/detail_token_reslt.php/?sess_user_id=` + this.sesss_id + `&&userrole=` + this.userrole + `&&username=` + this.username, token1);
  }

  deletetoken(delet){

    return this.http.delete<Result>(`${this.http_url}/delete_token.php/?cancl_id=${delet}&&sess_user_id=${this.sesss_id}`);
  }




}
